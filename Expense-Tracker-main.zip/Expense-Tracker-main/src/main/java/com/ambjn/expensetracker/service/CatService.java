package com.ambjn.expensetracker.service;

public interface CatService {

}

